Inventory Management DBMS Dataset

Original CSV files:
- Customer.csv
- Employee.csv
- OrderDetails.csv
- Orders.csv
- Product.csv
- Region.csv
- Warehouse.csv

Added for the DBMS inventory project:
- Inventory.csv

Inventory.csv columns:
InventoryID   - Primary Key
ProductID     - Foreign Key -> Product.ProductID
WarehouseID   - Foreign Key -> Warehouse.WarehouseID
StockQuantity
ReorderLevel
ReorderQuantity

The Inventory.csv was generated from the Product and Warehouse IDs in the
original dataset. StockQuantity, ReorderLevel and ReorderQuantity are
project/sample inventory values, not original source measurements.


Correction applied:
- Product.csv Profit was recalculated as ProductListPrice - ProductStandardCost for all rows.


Final data-quality cleanup:
- Corrected 8 malformed CustomerEmail values and 2 malformed EmployeeEmail values to valid email formats.
- No business/relationship values were changed.


Final verification:
All required tables, primary keys, foreign keys, formulas, numeric constraints, email formats, and date fields were checked with 0 errors.
